--- ENGLISH ---

Over the years of playing the Settlers, it always bothered me how after triggering either the Dark Tribe theme or combat theme with the Mayans,
their normal music simply didn't resume. 

I also found out some time ago that the Trojans actually have a third settle track, which is missing from most
editions of the game (including my Gold edition). 

You likely never heard the Viking sea themes, either, because while the other races have those as part of their settle-playlist, 
the Vikings have their fight themes instead. Since the game is apparently not capable of detecting if the camera is showing the ocean,
the game simply never switches to their sea themes.
I decided against changing this, since it was likely intended by BlueByte to underscore the Viking warrior culture. If you want to change that, you can easily do so.

While looking through the SET4Tweaker files, I found the file that controls the music, and I was able to fix these problems.
Not sure what the BlueByte devs where thinking when they referred to the Mayan files with Roman variables - that just couldn't work.
Not to mention that they made three expansions for the game and never fixed it, but I managed to do so in about five minutes.

Additionally, this patch allows for maps where you actually play as the Dark Tribe to play music. However, in my experience the music remains unstable
and will often stop playing, presumably because the playing as the Dark Tribe wasn't intended and thus never fully developed.


HOW TO INSTALL:
Simply drag the SoundTracks.cfg into the game's "Config" folder. The game checks if a file like this one is present upon launch - normally, there isn't,
so it defaults to one we usually don't have access to.
Also, copy the missing trojan theme into your game's "Snd" folder.

To see if it's working, simply try to reproduce one of the bugs I mentioned above.


MODIFYING THIS FILE:
This file has a rather clear structure and syntax, so it's easy to change the individual race's playlist, main menu theme etc., and even add your own tracks.
You can disable a track (useful if you want to test something) by putting a semicolon BEFORE the actual command.
Note than when reverting to the usual settling music, the game always uses the first track in that playlist. 

If the music keeps stopping after a certain track ends, it may also be a bitrate issue. I cannot 100% confirm this, but the game appears to be picky about the bitrate of mp3s.
Even though some of the game's own tracks have odd bitrates like 126kb/s.
128 and 256 kb/s should work fine. Stuff like 192 results in the game playing the first track with such a bitrate, then stopping all music.





--- GERMAN ---

�ber die Jahre ist mir immer wieder aufgefallen, das bei den Mayas, nachdem die Musik f�r K�mpfe oder das Dunkle Volk getriggert wurde, die Musik einfach aufh�rt.

Ich habe auch vor einiger Zeit herausgefunden, dass die Trojaner einen dritten settle-track haben, 
der in den meisten Versionen des Spiels (einschlie�lich meiner Gold Edition) fehlt.

Ihr habt wahrscheinlich auch noch nie die Seemusik der Wikinger geh�rt. W�hrend die anderen V�lker diese in ihrer Standardplaylist haben, haben die Wikinger dort
ihre Kampfmusik. Das Spiel kann scheinbar auch gar nicht feststellen, ob die Kamera gerade den Ozean zeigt, daher wechselt das Spiel auch nie zur Seemusik.
Ich habe das nicht ge�ndert, da es vermutlich von BlueByte beabsichtigt war, um die Kriegerkultur der Wikinger hervorzuheben.
Wenn ihr das �ndern wollt, k�nnt ihr das relativ einfach selbst tun.

W�hrend ich die SET4Tweaker Dateien durchgesehen habe, habe ich auch die Datei gefunden, die die Musik steuert, und konnte die beiden ersten Fehler beheben.
Keine Ahnung was sich die Leute von BlueByte dabei gedacht haben, die Mayamusik mit R�mervariablen anzusteuern. Das konnte ja nicht funktionieren.
Abgesehen davon, dass sie drei Erweiterungen f�r das Spiel gemacht haben und den Fehler nie behoben haben, ich das aber in f�nf Minuten hinbekommen habe.

Zus�tzlich erm�glicht der Patch, dass in Karten, in denen ihr als das Dunkle Volk spielt, Musik abgespielt wird. In meiner Erfahrung bleibt die Musik aber instabil
und wird oft einfach aufh�ren, vermutlich weil ein spielbares Dunkles Volk nicht vorgesehen war und daher nie richtig entwickelt wurde.


INSTALLATION:
Einfach die SoundTracks.cfg in den "Config" Ordner des Spiels kopieren. Das Spiel pr�ft beim Start immer, ob so eine Datei vorhanden ist.
Normalerweise gibt es keine, also nutzt das Spiel die Standardeinstellungen, auf die wir keinen Einfluss haben.

Kopiert au�erdem den fehlenden Trojaner Track in den "Snd" Ordner des Spiels.

Um zu sehen, ob es funktioniert, versucht einfach, einen der oben genannten Fehler zu reproduzieren.


DIE DATEI VER�NDERN:
Diese Datei hat eine recht klare Struktur und Syntax, was es einfach macht, die Playlisten der einzelnen V�lker, 
die Musik im Hauptmen� usw. zu �ndern und sogar eure eigenen Tracks hinzuzuf�gen.
Ihr k�nnt einzelne Tracks deaktivieren (n�zulich zum testen), indem ihr ein Semikolon VOR den Befehl setzt.
Beachtet, das dass Spiel beim Wechsel zur�ck zur Standardmusik immer den ersten Track in dieser Playlist sucht. 

Falls die Musik immer wieder nach einem bestimmten Track aufh�rt, k�nnte dies auch an der Bitrate liegen. Ich kann dies nicht 100%ig best�tigen,
aber das Spiel scheint w�hlerisch zu sein, was die Bitrate seiner mp3s angeht (obwohl einige seiner eigenen Tracks komische Bitraten wie 126 kb/s haben).
128 und 256 kb/s scheinen zu funktionieren. 192 kb/s scheint dazu zu f�hren, dass der erste Track in der Liste mit einer solchen Bitrate abgespielt wird und die
Musik dann einfach aufh�rt.