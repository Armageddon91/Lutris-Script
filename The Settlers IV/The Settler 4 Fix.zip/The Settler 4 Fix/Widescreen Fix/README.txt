Die Siedler IV Platin Edition Widescreen

Mithilfe dieser Dateien ist es m�glich, die Siedler 4 in den folgenden Aufl�sungen zu spielen:

1024x600
1280x720
1280x800
1366x768
1440x900
1680x1050
1920x1080
1920x1200

Um die gew�nschte Aufl�sung zu installieren, geht wie folgt vor:

1. Gew�nschten Aufl�sungsordner �ffnen und die GfxEngine.dll kopieren.

2. Ordner "Exe" im Siedler 4 Installationsverzeichnis �ffnen und GfxEngine.dll �berschreiben.

3. Die Aufl�sung 1024x786 wurde nun mit der gew�nschten Custom-Aufl�sung �berschrieben.

Viel Spa� beim Zocken!